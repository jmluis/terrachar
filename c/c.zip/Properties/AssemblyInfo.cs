﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("cTerrachar")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ChbShoot")]
[assembly: AssemblyProduct("cTerrachar")]
[assembly: AssemblyCopyright("Copyright © ChbShoot 2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("516cf36d-243d-4e17-8446-0bd83d9a4350")]

// Version information for an assembly consists of the following three values:
//
//		Major Version (major overhauls, no guaranteed backward compatibility)
//		Minor Version (minor changes, might require small changes to be backward compatible)
//		Revision (always guarantees backward compatibility)
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0")]
[assembly: AssemblyFileVersion("1.0.0")]
